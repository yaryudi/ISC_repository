'''
채팅 예제 구현 코드: https://bokyeong-kim.github.io/python/flask/2020/05/09/flask(1).html

관련 파일: chattest_exam1.html

테스트시 창 2개를 띄우고 socketio 통신이 잘 되는 지 확인
'''

from flask import Flask, render_template
from flask_socketio import SocketIO

app = Flask(__name__)
app.config['SECRET_KEY'] = '비밀번호 설정'
socketio = SocketIO(app)

#채팅방 /inroom
#시작 시 페이지로 이동
@app.route('/inroom')
def go_inroom():
    return render_template('chat_test_inroom.html')

#메시지 수신 신호
def messageReceived(methods=['GET', 'POST']):
    print('message was received!!!')
   
#채팅방 바깥 / 
@app.route('/')
def go_outroom():
    return render_template('chat_test_outroom.html')

#클라이언트-> socket.emit('my event', data), 서버에서 이 이벤트를 처리하는 함수가 실행
@socketio.on('my event')
def handle_my_custom_event(json, methods=['GET', 'POST']):
    #클라이언트로부터 받은 json 데이터를 로그로 출력합니다.
    print('received my event: ' + str(json))
    
    #여기서 받은 채팅기록을 DB에 저장 - 발신자 + 전송 시간 + 전송내용
    
    
    #socketio.emit은 서버가 클라이언트로 메시지를 보낼 때 사용하는 함수 + json과 같이 보낸다.
    #callback=messageReceived, 클라이언트에서 응답을 보내면 messageReceived 함수를 실행(callback)
    socketio.emit('my response', json, callback=messageReceived)

if __name__ == '__main__':
    socketio.run(app, debug=True)